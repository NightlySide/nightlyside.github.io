# EXERCICE 3 - L'HISTOIRE SANS FIN

_Il semblerait qu'un fragment de clé soit caché dans cet exercice._

Je me permets de vous partager un classique revisité récemment par l'une de mes séries favorites.

> - This is Suzie, I copy.
> - Suzie!
> - Dusty-bun!?

> Look at what you see.
> But not only !

> What is the secret of the never ending story ?

M. X. (-..-)

Faut pas chercher midi à quatorze heures mais plutôt Samuel à midi !

P.S : Samuel est un morse, choisi lui la bonne piste !

---

# Instructions :

La stéganographie est l'art de la dissimulation : son objet est de faire passer inaperçu un message dans un autre message. Elle se distingue de la cryptographie, « art du secret », qui cherche à rendre un message inintelligible à autre que qui-de-droit. Pour prendre une métaphore, la stéganographie consisterait à enterrer son argent dans son jardin là où la cryptographie consisterait à l'enfermer dans un coffre-fort — cela dit, rien n'empêche de combiner les deux techniques, de même que l'on peut enterrer un coffre dans son jardin.

C'est un mot issu du grec ancien στεγανός / steganós (« étanche ») et γραφή / graphế (« écriture »).

Sources : https://fr.wikipedia.org/wiki/St%C3%A9ganographie

# Votre objectif :

Un fragment de clé est dissimulé dans cet exercice (NeverEndingStory). À vous de le retrouver.

Pour valider auprès d'un juge, il vous suffira de donner le fragment de clé trouvé.

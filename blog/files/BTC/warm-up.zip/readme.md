# EXERCICE 1 - WARM UP

_Lettre de M. X :_

À ma chère famille,

Ave,

Si vous recevez cette lettre, c'est qu'il m'est arrivé quelque chose.
J'imagine, avide d'argent comme vous êtes, que vous souhaitez plutôt mettre la main sur ma fortune plutôt que de dépenser votre énergie pour me retrouver.
Celà ne m'arrange pas car j'aimerai plutôt être secouru. Enfin, vous savez comme je suis prévoyant, j'ai tout prévu.

En échange de prévenir les forces de l'ordre, je vous propose le contenu de mon portefeuille numérique. Aujourd'hui, il devrait être valorisé à plusieurs millions si le cours ne s'est pas effondré.

Je vous lègue cette clé U.S.B où j'ai dissimulé plusieurs énigmes menant à des framgents qui vous permettront de reconstituer ma clé privée vous permettant d'accéder à ce portefeuille. Pour aider les enquêteurs, j'y ai également introduis plusieurs éléments sur où je me trouvais et avec qui je me trouvais avant que cette clé ne soit envoyée. Pour être sûr que vous contactiez réellement les forces de l'ordre, toute information est cachée. Je doute que vous parviendrez par vous-mêmes à résoudre une quelconque de ces énigmes, alors entourez-vous des meilleurs enquêteurs.

Pour commencer, je vous propose de déchiffrer le contenu du message que je vous ai laissé (encrypted.txt).
Sachez que César, à son époque, utilisait ce même système pour communiquer avec ses généraux. Je n'ai pas changé la clé, mais l'alphabet est bien différent. Et il pourrait bien être juste sous vos yeux.

M. X

---

# Instructions :

Le chiffrement de César est une méthode de chiffrement par décalage. Ce chiffrement aurait été utilisé par Jules César (d'où son nom) dans certaines de ses correspondances militaires.

Le principe est simple.
Chaque lettre du message est remplacée par la lettre dans l'ordre l'alphabet avec un décallage de 3 vers la droite : A devient D, B devient E, ... et on reprend au début pour les dernières lettres, W devient Z, X devient A, Y devient B, Z devient C.

- [ABCDEFGHIJKLMNOPQRSTUVWXYZ] - ALPHABET DANS L'ORDRE
- [DEFGHIJKLMNOPQRSTUVWXYZABC] - ALPHABET DECALLE DE 3 LETTRES VERS LA DROITE

Pour déchiffrer le message codé, il suffit d'appliquer le décallage vers la gauche.

    Exemple :

    BONJOUR -> ERQMRXU (Décallage de 3 vers la droite)
    ERQMRXU -> BONJOUR (Décallage de 3 vers la gauche)

Il existe plusieurs variantes, notamment il est possible de modifier le décallage (un décallage de 1, 4, 23, ...) mais il est aussi possible d'en changer l'alphabet (exemple : utiliser l'alphabet à l'envers).
César, selon les écrits, l'utilisait avec l'alphabet grec composé de 24 lettres non compréhensible par la plupart des Gaulois.

    Exemple avec un décallage de 7 :

    BONJOUR -> IVUQVBY (Décallage de 7 vers la droite)
    IVUQVBY -> BONJOUR (Décallage de 7 vers la gauche)

    Exemple avec un alphabet modifié et un décallage de 3 :

    [HXCJSWAGLQZBMNUYVDFKPEOITR] - EXEMPLE D'UN ALPHABET MODIFIE
    BONJOUR -> URVARDC (Décallage de 3 vers la droite)
    URVARDC -> BONJOUR (Décallage de 3 vers la gauche)

# Votre objectif :

Déchiffrez le texte de M. X (encrypted.txt) qui paraît chiffré avec le chiffrement de César. Il semblerait que M. X ait changé l'ordre de l'alphabet (voir variante), il ne reste plus qu'à trouver le bon ordre...

Pour résoudre cette exercice, le plus simple est dans un premier temps de réaliser l'algorithme de chiffrement et de déchiffrement. Les exemples cités pourront vous aider à valider votre algorithme. Puis, dans un second temps il vous faudra déchiffrer le texte de M. X, pour cela vous devrez trouver l'alphabet modifié qu'a utilisé M. X pour chiffrer son texte. L'alphabet en question n'est pas celui présent dans l'exemple, c'est à vous de déterminer l'ordre de cet alphabet. **Pour le trouver et déterminer cet ordre, analyser bien les éléments de la lettre de M. X, plusieurs indices peuvent y être cachés.**

Pour valider auprès d'un juge, il vous faudra déchiffrer le texte de M. X et donner le flag correspondant.

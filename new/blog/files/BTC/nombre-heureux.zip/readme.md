# EXERCICE 7 - NOMBRE HEUREUX

En fouillant dans la clé USB, vous tombez sur un dossier contenant un morceau d'annuaire téléphonique, et un fichier contenant des instructions.

"Depuis quelques mois, un de mes collègues me harcèle et j'ai peur qu'il finisse par me faire du mal. Des fois qu'il tomberait sur ce document, je préfère ne pas le citer directement ..."

Aidez la police en trouvant l'identité de la personne dont M. X parle.

---

# Instructions :

Un "nombre heureux" est défini comme suit :

Partant de n'importe quel entier positif, remplacer cet entier par la somme des carrés des chiffres qui le composent, et répéter le processus jusqu'à ce que le nombre soit égal à 1 (auquel cas le nombre est qualifié de "heureux").
Si le processus boucle (i.e. on repasse sur un nombre déja obtenu lors d'une étape précédente), alors le chiffre n'est pas "heureux" et le processus peut être stoppé.

__Exemple 1 :__

Prenons le nombre 28, les différentes itérations de l'algorithme donnent les étapes suivantes :

28  ->  2² + 8² = 4 + 64 = 68  
68  ->  6² + 8² = 36 + 64 = 100  
100 ->  1² + 0² + 0² = 1  

Le nombre 28 est donc un nombre heureux

__Exemple 2 :__

Prenons le nombre 42 les différentes itérations de l'algorithme donnent les étapes suivantes :

42 -> 4² + 2² = 16 + 4 = 20  
20 -> 2² + 0 = 4  
4 -> 4² = 16  
16 -> 1² + 6² = 1 + 36 = 37  
37 -> 3² + 7² = 9 + 49 = 58  
58 -> 5² + 8² = 25 + 64 = 89  
89 -> 8² + 9² = 64 + 81 = 145  
145 -> 1² + 4² + 5² = 1 + 16 + 25 = 42  

On retombe sur 42, qui a déja été atteint lors d'une étape précédente (ici, c'était le nombre initial).
Le nombre 42 n'est donc pas un nombre heureux.


# Votre objectif :

Vous devez trouver la **somme** de tous les nombres heureux qui remplissent les conditions suivantes :
- Est compris entre 0 et 200000 inclus
- Est premier
- Est impair

(Pour rappel, un nombre premier est un nombre qui n'est divisible que par 1 et lui-même, et qui possède au moins 2 diviseurs distincts)

A l'aide de l'annuaire et de ce nombre, retrouvez l'identité de la personne dont M. X parle.
